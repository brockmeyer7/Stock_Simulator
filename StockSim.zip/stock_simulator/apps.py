from django.apps import AppConfig


class StockSimulatorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stock_simulator'
